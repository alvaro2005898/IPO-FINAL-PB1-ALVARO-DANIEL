// app.js - Lógica Principal del Mapa y Saltos Cuánticos

// Variables Globales
let userPos = [40.416, -3.703]; 
let userCountryCode = 'es';
let selectedLocation = null;
let activeSub = "NONE";
let userMarker = null;
let portalMarker = null;
let targetSignalMarker = null;
let jumpLine = null; 
let travelHistory = []; 
const SUB_PRICES = { CABINAS: 15000, TOTAL: 45000, UPGRADE_TOTAL: 32000 };

// Accesibilidad de Teclado
document.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' || e.key === ' ') {
        const activeEl = document.activeElement;
        if (activeEl && activeEl.getAttribute('role') === 'button') {
            e.preventDefault();
            activeEl.click();
        }
    }
});

document.getElementById('search-input').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        manualSearch();
    }
});

// Actualización de UI (Llamada desde auth.js)
function updatePlanUI() {
    const badge = document.getElementById('plan-trigger');
    const display = document.getElementById('plan-display');
    badge.className = 'plan-badge';
    if (activeSub === 'CABINAS') { 
        badge.classList.add('plan-cabinas'); 
        display.innerText = "Plan Cabinas"; 
        badge.setAttribute('aria-label', "Suscripción actual: Plan Cabinas. Clic para gestionar.");
    } else if (activeSub === 'TOTAL') { 
        badge.classList.add('plan-total'); 
        display.innerText = "Plan Total VIP"; 
        badge.setAttribute('aria-label', "Suscripción actual: Plan Total VIP. Clic para gestionar.");
    } else { 
        display.innerText = "Plan Estándar"; 
        badge.setAttribute('aria-label', "Suscripción actual: Plan Estándar. Clic para gestionar.");
    }
}

// Inicialización del Mapa
const map = L.map('map', { zoomControl: false }).setView(userPos, 6);
L.tileLayer('https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}').addTo(map);

userMarker = L.marker(userPos, {
    icon: L.divIcon({ className: '', html: '<div class="user-marker"></div>', iconSize: [20, 20] })
}).addTo(map);

if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition((position) => {
        userPos = [position.coords.latitude, position.coords.longitude];
        map.setView(userPos, 13);
        userMarker.setLatLng(userPos);
        fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${userPos[0]}&lon=${userPos[1]}&addressdetails=1`)
            .then(r => r.json()).then(d => { if(d.address) userCountryCode = d.address.country_code; });
    });
}

function centerMapOnUser() {
    map.flyTo(userPos, 14, { duration: 1 });
}

function closePreview() {
    document.getElementById('preview').style.display = 'none';
    if(jumpLine) { map.removeLayer(jumpLine); jumpLine = null; }
    if(targetSignalMarker) { map.removeLayer(targetSignalMarker); targetSignalMarker = null; }
}

function toggleHistory() {
    const panel = document.getElementById('history-panel');
    panel.classList.toggle('minimized');
}

map.on('click', e => {
    document.getElementById('user-menu').style.display = 'none';
    reverseGeocode(e.latlng.lat, e.latlng.lng);
});

async function manualSearch() {
    const q = document.getElementById('search-input').value;
    if(!q) return;
    try {
        const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${q}&limit=1&addressdetails=1`);
        const data = await res.json();
        if(data[0]) reverseGeocode(data[0].lat, data[0].lon);
        else alert("Ubicación no encontrada en la red.");
    } catch(e) { console.error(e); }
}

async function fetchRealWeather(lat, lng) {
    try {
        const response = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&current=temperature_2m,weather_code`);
        const data = await response.json();
        const temp = Math.round(data.current.temperature_2m);
        const code = data.current.weather_code;
        let desc = "Despejado"; let icon = "☀️";
        if(code >= 1 && code <= 3) { desc = "Parcialmente nublado"; icon = "⛅"; }
        else if(code >= 45 && code <= 48) { desc = "Niebla"; icon = "🌫️"; }
        else if(code >= 51 && code <= 67) { desc = "Lluvia"; icon = "🌧️"; }
        else if(code >= 71 && code <= 77) { desc = "Nieve"; icon = "❄️"; }
        else if(code >= 80) { desc = "Tormenta"; icon = "⛈️"; }
        return { temp, desc, icon };
    } catch (e) {
        return { temp: "--", desc: "Error de sensor", icon: "⚠️" };
    }
}

async function reverseGeocode(lat, lng) {
    let city = "Zona Cuántica Desconocida";
    let destCountryCode = '??';
    let isInt = false;
    let isWater = false;
    let cityCenter = [lat, lng];
    let crowdData = { label: "MÍNIMA", color: "#28a745" };

    try {
        const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&addressdetails=1`);
        const data = await res.json();
        
        if (!data || !data.address || (!data.address.country && !data.address.ocean)) {
            isWater = true;
        } else {
            const type = (data.type || "").toLowerCase();
            const category = (data.category || "").toLowerCase();
            const displayName = (data.display_name || "").toLowerCase();
            const strictWater = ['ocean', 'sea', 'mar', 'rio', 'river', 'lake', 'lago', 'water', 'basin', 'reservoir'];
            const urbanEvidence = data.address.road || data.address.suburb || data.address.city || data.address.town || data.address.village || data.address.postcode || data.address.hamlet;
            const matchesWater = strictWater.some(kw => displayName.includes(kw) || type.includes(kw) || category.includes(kw));
            isWater = matchesWater && !urbanEvidence;

            const cityName = data.address.city || data.address.town || data.address.village || data.address.state || data.address.country || "Punto Terrestre";
            city = cityName;
            destCountryCode = data.address.country_code;
            isInt = destCountryCode !== userCountryCode;
            
            const searchRes = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${cityName},${data.address.country || ''}&limit=1&addressdetails=1`);
            const searchData = await searchRes.json();
            
            if (searchData[0]) {
                cityCenter = [parseFloat(searchData[0].lat), parseFloat(searchData[0].lon)];
                const importance = searchData[0].importance || 0.01;
                const hour = new Date().getHours();
                let multiplier = (hour > 8 && hour < 22) ? 1.5 : 0.2;
                const densityScore = Math.pow(importance, 2.5) * multiplier;
                
                if (densityScore > 0.75) crowdData = { label: "MUY ALTA", color: "#dc3545" };
                else if (densityScore > 0.45) crowdData = { label: "ALTA", color: "#fd7e14" };
                else if (densityScore > 0.20) crowdData = { label: "MEDIA", color: "#ffc107" };
                else if (densityScore > 0.05) crowdData = { label: "BAJA", color: "#17a2b8" };
                else crowdData = { label: "MUY BAJA / MÍNIMA", color: "#28a745" };
            }
        }
    } catch (error) { 
        isWater = true; 
    }

    const realWeather = await fetchRealWeather(lat, lng);

    selectedLocation = { 
        lat, lng, city, isWater, centerPos: cityCenter,
        isInternational: isInt, countryCode: destCountryCode, 
        distance: getDist(userPos[0], userPos[1], lat, lng),
        weather: realWeather, crowd: crowdData
    };

    updatePreviewUI();
}

function updatePreviewUI() {
    if(!selectedLocation) return;
    if(jumpLine) map.removeLayer(jumpLine);
    if(targetSignalMarker) map.removeLayer(targetSignalMarker);

    const statusColor = selectedLocation.isWater ? 'var(--danger)' : 'var(--primary)';

    const latlngs = [userPos, [selectedLocation.lat, selectedLocation.lng]];
    jumpLine = L.polyline(latlngs, { color: statusColor, weight: 2, dashArray: '10, 10', opacity: 0.7 }).addTo(map);

    targetSignalMarker = L.marker([selectedLocation.lat, selectedLocation.lng], {
        icon: L.divIcon({ 
            className: '', 
            html: `<div class="radar-container" style="color:${statusColor}"><div class="radar-wave"></div><div class="radar-wave"></div><div class="radar-dot"></div></div>`, 
            iconSize: [40, 40], iconAnchor: [20, 20]
        })
    }).addTo(map);
    
    document.getElementById('prev-title').innerText = selectedLocation.city;
    document.getElementById('dist-info').innerText = `${Math.round(selectedLocation.distance)} km | ${selectedLocation.isInternational ? 'Internacional 🌍' : 'Nacional 🏳️'}`;
    document.getElementById('temp-val').innerText = `${selectedLocation.weather.temp}°C`;
    document.getElementById('weather-desc').innerText = selectedLocation.weather.desc;
    document.getElementById('weather-icon').innerText = selectedLocation.weather.icon;
    
    const crowdEl = document.getElementById('crowd-val');
    crowdEl.innerText = selectedLocation.crowd.label;
    crowdEl.style.color = selectedLocation.crowd.color;

    const alertBox = document.getElementById('water-alert');
    const jumpBtn = document.getElementById('jump-btn');
    
    if(selectedLocation.isWater) {
        alertBox.style.display = 'block'; 
        jumpBtn.disabled = true; 
        jumpBtn.innerText = "SALTO BLOQUEADO";
    } else {
        alertBox.style.display = 'none'; 
        jumpBtn.disabled = false; 
        jumpBtn.innerText = "INICIAR SALTO";
    }
    document.getElementById('preview').style.display = 'block';
    
    setTimeout(() => document.querySelector('.preview-content .close-btn').focus(), 100);
    map.flyTo([selectedLocation.lat, selectedLocation.lng], 14);
}

function getDist(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const dLat = (lat2-lat1) * Math.PI / 180;
    const dLon = (lon2-lon1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon/2) * Math.sin(dLon/2);
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

function openSubscriptionMenu(fromPayment = false) {
    const modal = document.getElementById('modal-content');
    let content = `<div class="close-btn" onclick="closeModal()" tabindex="0" role="button" aria-label="Cerrar ventana" title="Cerrar">✖</div>
                   <h2 id="modal-title" style="margin-top:0; margin-right: 20px;">Suscripciones Quantum</h2>`;
                   
    if (activeSub === "NONE") {
        content += `
            <p style="font-size:14px; color:#666;">Selecciona un plan corporativo para saltos ilimitados.</p>
            <div class="option" onclick="setSub('CABINAS', ${fromPayment})" tabindex="0" role="button" aria-label="Seleccionar Plan Cabinas" style="text-align:left; border-color:var(--cabinas);">
                <div style="font-weight:800; color:var(--cabinas);">PLAN CABINAS</div>
                <div style="font-size:11px;">Centros ilimitados + 50% en COORDENADAS</div>
                <div class="price" style="font-size:18px; color:#333; margin-top:5px;">${SUB_PRICES.CABINAS.toLocaleString()}€/mes</div>
            </div>
            <div class="option" onclick="setSub('TOTAL', ${fromPayment})" tabindex="0" role="button" aria-label="Seleccionar Plan Total VIP" style="text-align:left; border-color:var(--vip);">
                <div style="font-weight:800; color:var(--vip);">PLAN TOTAL VIP</div>
                <div style="font-size:11px;">Transporte total sin límites nacionales.</div>
                <div class="price" style="font-size:18px; color:#333; margin-top:5px;">${SUB_PRICES.TOTAL.toLocaleString()}€/mes</div>
            </div>`;
    } else if (activeSub === "CABINAS") {
        content += `
            <p style="font-size:14px; color:#666;">Mejora tu Plan Cabinas con tarifa preferencial:</p>
            <div class="option" onclick="setSub('TOTAL', ${fromPayment})" tabindex="0" role="button" aria-label="Mejorar a Plan Total VIP" style="text-align:left; border-color:var(--vip); background: #fffdf0;">
                <div style="position:absolute; top:0; right:0; background:var(--vip); color:black; font-size:9px; padding:3px 8px; font-weight:bold;">UPGRADE</div>
                <div style="font-weight:800; color:var(--vip);">MEJORAR A PLAN TOTAL VIP</div>
                <div class="price" style="font-size:18px; color:#333; margin-top:5px;"><strike style="color:#999; font-size:14px;">${SUB_PRICES.TOTAL.toLocaleString()}€</strike> ${SUB_PRICES.UPGRADE_TOTAL.toLocaleString()}€/mes</div>
            </div>`;
    } else {
        content += `<p style="font-weight:bold; color:var(--vip); margin-bottom:20px;">Protocolo TOTAL VIP activo.</p>`;
    }
    
    const backAction = fromPayment ? 'renderPaymentModal()' : 'closeModal()';
    content += `<button class="btn-action" onclick="${backAction}" style="background:#eee; color:#333;">VOLVER</button>`;
    
    modal.innerHTML = content;
    document.getElementById('modal').style.display = 'flex';
    setTimeout(() => document.querySelector('#modal-content .close-btn').focus(), 100);
}

function handleTransportRequest() {
    if(selectedLocation.isWater) return; 
    renderPaymentModal();
    document.getElementById('modal').style.display = 'flex';
}

function renderPaymentModal() {
    const { isInternational, distance, city } = selectedLocation;
    let pCabina = Math.round(isInternational ? (1200 + distance * 0.4) : (250 + distance * 0.8));
    let pExacto = Math.round(isInternational ? (3000 + distance * 0.8) : (600 + distance * 1.5));
    const modal = document.getElementById('modal-content');
    
    let baseHTML = `<div class="close-btn" onclick="closeModal()" tabindex="0" role="button" aria-label="Cancelar y cerrar" title="Cerrar">✖</div><h2 id="modal-title" style="margin-right: 20px;">Salto a ${city}</h2>`;
    
    if (activeSub === "TOTAL") {
        modal.innerHTML = baseHTML + `<div style="display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin:20px 0;"><div class="option" onclick="confirmPayment('CABINA')" tabindex="0" role="button" aria-label="Seleccionar salto a centro ciudad"><h4>CENTRO CIUDAD (CABINA)</h4><div class="price">GRATIS (VIP)</div></div><div class="option ${isInternational ? 'disabled' : ''}" onclick="${isInternational ? '' : "confirmPayment('EXACTO')" }" tabindex="0" role="button" aria-label="Seleccionar salto exacto a coordenadas"><h4>COORDENADAS</h4><div class="price">${isInternational ? '--' : 'GRATIS (VIP)'}</div></div></div>`;
    } else if (activeSub === "CABINAS") {
        const pExactoDesc = Math.round(pExacto / 2);
        modal.innerHTML = baseHTML + `<div style="display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin:20px 0;"><div class="option" onclick="confirmPayment('CABINA')" tabindex="0" role="button" aria-label="Seleccionar salto a centro ciudad"><h4>CENTRO CIUDAD (CABINA)</h4><div class="price">GRATIS</div></div><div class="option ${isInternational ? 'disabled' : ''}" onclick="${isInternational ? '' : "confirmPayment('EXACTO')" }" tabindex="0" role="button" aria-label="Seleccionar salto exacto a coordenadas">${!isInternational ? '<div style="position:absolute; top:0; right:0; background:#FF3D00; color:white; font-size:9px; padding:2px 5px; font-weight:bold;">-50%</div>' : ''}<h4>COORDENADAS</h4><div class="price">${isInternational ? '--' : pExactoDesc + '€'}</div></div></div><button class="btn-action" onclick="openSubscriptionMenu(true)">MEJORAR PLAN</button>`;
    } else {
        modal.innerHTML = baseHTML + `<div style="display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin:20px 0;"><div class="option" onclick="confirmPayment('CABINA')" tabindex="0" role="button" aria-label="Seleccionar salto a centro ciudad"><h4>CENTRO CIUDAD (CABINA)</h4><div class="price">${pCabina}€</div></div><div class="option ${isInternational ? 'disabled' : ''}" onclick="${isInternational ? '' : "confirmPayment('EXACTO')" }" tabindex="0" role="button" aria-label="Seleccionar salto exacto a coordenadas"><h4>COORDENADAS</h4><div class="price">${isInternational ? '--' : pExacto + '€'}</div></div></div><button class="btn-action" onclick="openSubscriptionMenu(true)">MEJORAR PLAN</button>`;
    }
    setTimeout(() => document.querySelector('#modal-content .close-btn').focus(), 100);
}

function confirmPayment(tipo) { alert("Transacción cuántica confirmada."); closeModal(); doJump(tipo); }

function doJump(tipo) {
    const flash = document.getElementById('flash');
    const targetPos = (tipo === 'CABINA') ? selectedLocation.centerPos : [selectedLocation.lat, selectedLocation.lng];
    addToHistory(selectedLocation.city, tipo, targetPos[0], targetPos[1]);
    flash.style.opacity = '1';
    setTimeout(() => {
        flash.style.opacity = '0';
        document.getElementById('preview').style.display = 'none';
        if(targetSignalMarker) { map.removeLayer(targetSignalMarker); targetSignalMarker = null; }
        if(jumpLine) { map.removeLayer(jumpLine); jumpLine = null; }
        if(portalMarker) map.removeLayer(portalMarker);
        const currentPortal = L.marker(targetPos, { icon: L.divIcon({ className: '', html: '<div class="portal-marker"></div>', iconSize: [40, 40] }) }).addTo(map);
        portalMarker = currentPortal;
        map.flyTo(targetPos, 18);
        userPos = targetPos;
        userCountryCode = selectedLocation.countryCode; 
        userMarker.setLatLng(userPos);
        setTimeout(() => { if(currentPortal) map.removeLayer(currentPortal); }, 5000);
    }, 600);
}

// --- NUEVA LÓGICA DE HISTORIAL Y FAVORITOS ---
function addToHistory(city, type, lat, lng) {
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const displayType = type === 'EXACTO' ? 'COORDENADAS' : 'CABINA';
    const timestamp = Date.now(); // Identificador único y para ordenar
    
    document.getElementById('history-panel').classList.remove('minimized');
    
    // Añadimos el nuevo viaje al array
    travelHistory.push({ city, type: displayType, time, lat, lng, timestamp, isFavorite: false });
    
    // Reordenar: Favoritos arriba, luego los más recientes
    travelHistory.sort((a, b) => {
        if (a.isFavorite === b.isFavorite) {
            return b.timestamp - a.timestamp; // Más reciente primero
        }
        return a.isFavorite ? -1 : 1; // Favoritos primero
    });

    if(travelHistory.length > 50) travelHistory.pop(); // Límite de 50 saltos
    
    saveHistoryToDB();
    updateHistoryUI();
}

function toggleFavorite(timestamp, event) {
    event.stopPropagation(); // Evita que al hacer clic en la estrella se haga el salto
    const item = travelHistory.find(i => i.timestamp === timestamp);
    if (item) {
        item.isFavorite = !item.isFavorite; // Cambiamos estado
        
        // Volvemos a ordenar la lista
        travelHistory.sort((a, b) => {
            if (a.isFavorite === b.isFavorite) {
                return b.timestamp - a.timestamp;
            }
            return a.isFavorite ? -1 : 1;
        });

        saveHistoryToDB();
        updateHistoryUI();
    }
}

function saveHistoryToDB() {
    const activeEmail = localStorage.getItem('telemaps_activeUser');
    if (activeEmail) {
        let users = JSON.parse(localStorage.getItem('telemaps_db')) || {};
        if (users[activeEmail]) {
            users[activeEmail].travelHistory = travelHistory;
            localStorage.setItem('telemaps_db', JSON.stringify(users));
        }
    }
}

function updateHistoryUI() {
    const list = document.getElementById('history-list');
    if (travelHistory.length === 0) {
        list.innerHTML = '<div style="font-size: 11px; color: #555; text-align: center; padding: 10px;">No hay viajes recientes</div>';
        return;
    }
    
    list.innerHTML = travelHistory.map((item) => {
        const favClass = item.isFavorite ? 'active' : '';
        // Estrella vectorial SVG (Rellena si es favorito, transparente si no)
        const starSVG = `
            <svg width="16" height="16" viewBox="0 0 24 24" fill="${item.isFavorite ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
            </svg>
        `;

        return `<div class="history-item" onclick="selectFromHistory(${item.timestamp})" tabindex="0" role="button" aria-label="Viajar a ${item.city}">
            <div class="history-item-content">
                <button class="fav-btn ${favClass}" onclick="toggleFavorite(${item.timestamp}, event)" aria-label="${item.isFavorite ? 'Quitar de favoritos' : 'Añadir a favoritos'}">
                    ${starSVG}
                </button>
                <div>
                    <div class="history-dest">${item.city}</div>
                    <div style="font-size:10px; color:#777;">${item.time}</div>
                </div>
            </div>
            <div class="history-type">${item.type}</div>
        </div>`;
    }).join('');
}

function selectFromHistory(timestamp) {
    const item = travelHistory.find(i => i.timestamp === timestamp);
    if (item) reverseGeocode(item.lat, item.lng);
}
// ---------------------------------------------

function setSub(t, fromPayment = false) {
    activeSub = t;
    const activeEmail = localStorage.getItem('telemaps_activeUser');
    if (activeEmail) {
        let users = JSON.parse(localStorage.getItem('telemaps_db')) || {};
        if (users[activeEmail]) {
            users[activeEmail].activeSub = activeSub;
            localStorage.setItem('telemaps_db', JSON.stringify(users));
        }
    }
    updatePlanUI(); 
    alert("Protocolo " + t + " activo.");

    if (fromPayment) {
        renderPaymentModal();
    } else {
        closeModal();
    }
}

function closeModal() { document.getElementById('modal').style.display = 'none'; }

// Inicializar la aplicación comprobando el usuario tras cargar todo
document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
});