// auth.js - Autenticación y Perfil del Usuario

function checkAuth() {
    const activeEmail = localStorage.getItem('telemaps_activeUser');
    if (!activeEmail) {
        window.location.href = 'login.html';
        return;
    }

    const users = JSON.parse(localStorage.getItem('telemaps_db')) || {};
    const user = users[activeEmail] || {};

    let displayName = user.name || activeEmail.split('@')[0];
    let fullName = `${user.name || displayName} ${user.surname || ''}`.trim();
    let initial = displayName.charAt(0).toUpperCase();

    document.getElementById('nav-avatar').innerText = initial;
    document.getElementById('nav-username').innerText = displayName;
    document.getElementById('menu-fullname').innerText = fullName;
    document.getElementById('menu-email').innerText = activeEmail;

    // Estas variables globales se definen en app.js
    if (typeof activeSub !== 'undefined') activeSub = user.activeSub || "NONE";
    if (typeof travelHistory !== 'undefined') {
        travelHistory = user.travelHistory || [];
        // Retrocompatibilidad: Añadir timestamp e isFavorite a viajes antiguos
        travelHistory.forEach((item, index) => {
            if (!item.timestamp) item.timestamp = Date.now() - index * 1000;
            if (typeof item.isFavorite === 'undefined') item.isFavorite = false;
        });
    }

    if (typeof updatePlanUI === 'function') updatePlanUI();
    if (typeof updateHistoryUI === 'function') updateHistoryUI();
}

function toggleUserMenu() {
    const menu = document.getElementById('user-menu');
    menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
}

function openEditProfile() {
    document.getElementById('user-menu').style.display = 'none';
    const activeEmail = localStorage.getItem('telemaps_activeUser');
    const users = JSON.parse(localStorage.getItem('telemaps_db')) || {};
    const user = users[activeEmail] || {};
    
    document.getElementById('edit-name').value = user.name || activeEmail.split('@')[0];
    document.getElementById('edit-surname').value = user.surname || '';
    document.getElementById('edit-pwd').value = ''; 
    document.getElementById('edit-pwd2').value = ''; 
    
    document.getElementById('edit-profile-modal').style.display = 'flex';
    setTimeout(() => document.getElementById('edit-name').focus(), 100);
}

function closeEditProfile() {
    document.getElementById('edit-profile-modal').style.display = 'none';
}

function saveProfile(e) {
    e.preventDefault();
    const activeEmail = localStorage.getItem('telemaps_activeUser');
    let users = JSON.parse(localStorage.getItem('telemaps_db')) || {};
    
    const newPwd = document.getElementById('edit-pwd').value;
    const newPwd2 = document.getElementById('edit-pwd2').value;

    if (newPwd.trim() !== '' || newPwd2.trim() !== '') {
        if (newPwd !== newPwd2) {
            alert('Las contraseñas no coinciden. Por favor, revísalo e inténtalo de nuevo.');
            return;
        }
        if (newPwd.length < 8) {
            alert('Por seguridad, la contraseña debe tener al menos 8 caracteres.');
            return;
        }
    }

    if (!users[activeEmail]) {
        users[activeEmail] = { password: 'simulacion_oauth', activeSub: "NONE", travelHistory: [] }; 
    }

    users[activeEmail].name = document.getElementById('edit-name').value;
    users[activeEmail].surname = document.getElementById('edit-surname').value;
    
    if (newPwd.trim() !== '') {
        users[activeEmail].password = newPwd;
    }

    localStorage.setItem('telemaps_db', JSON.stringify(users));
    
    alert('Perfil actualizado correctamente.');
    closeEditProfile();
    checkAuth();
}

function logout() {
    localStorage.removeItem('telemaps_activeUser');
    window.location.href = 'login.html';
}